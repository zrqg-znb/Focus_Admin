# Project Delivery Guidelines for Focus Admin

## 1. What this skill is for

Use this skill when a Focus Admin task needs an end-to-end delivery path:
- problem framing
- spec writing
- doc placement
- UI direction
- backend + frontend implementation
- verification

It is designed for the repository's stack:
- Django 5.2 + Django Ninja
- Vue 3 + Vben Admin
- zq-table for management data tables and header-cell filters
- MySQL 8
- pnpm monorepo frontend

## 2. Default delivery flow

1. Clarify the problem and success criteria.
2. Write a short spec before coding.
3. Save the spec into the repo docs tree.
4. Choose a UI direction that matches an internal admin product.
5. Implement backend and frontend changes in the repo's existing module structure.
6. Check whether the feature needs routes, menus, permissions, dictionaries, seed data, migrations, or docs entries.
7. Verify with lint, typecheck, compile, targeted tests, comment coverage, zq-table pagination, and header filter checks when relevant.

## 3. Spec rules

Every feature spec should include:
- problem statement
- goals
- non-goals
- target users
- API/page mapping
- design direction
- acceptance criteria
- risks and open questions

Keep specs concise. One page is usually enough unless the feature is cross-cutting.

## 4. Where to write things down

Preferred doc targets:
- `backend-django/docs/` for backend or product behavior specs
- `web/docs/` for frontend-facing guides or UI notes
- a feature's owning module docs when the feature is already deeply localized

Prefer Markdown.

## 5. UI direction rules

Focus Admin UI should feel like an operator console:
- compact and legible
- low visual noise
- strong hierarchy
- clear scan paths
- table-first for management data
- dialogs and drawers for edits

Avoid:
- landing-page composition
- decorative hero sections
- oversized cards with weak information density
- generic AI-style gradients and soft blobs

When a task touches presentation quality, use `frontend-design` to pressure-test the visual direction.

## 6. Frontend implementation rules

Use the local app's existing conventions:
- feature views live under `web/apps/web-ele/src/views/`
- list pages generally use `index.vue` plus `data.ts`
- all management data lists, CRUD lists, dashboard detail lists, and paginated data tables must prefer `useZqTable` / `zq-table`
- configure zq-table pagination explicitly with `pagerConfig: { enabled: true, pageSize: 20 }`, adding `pageSizes` when the workflow benefits from it
- in `proxyConfig.ajax.query`, map `page.currentPage` to backend `page` and `page.pageSize` to backend `pageSize`
- column-bound filters must live in the matching table header cell as a header filter dropdown, not in the top search area by default
- simple enum filters should use Element Plus / zq-table column filter passthrough when it fits
- complex filters use a `header-*` slot or reusable zq-table header filter component with a column label, Filter icon, and dropdown panel
- header filter dropdowns may host inputs, radio, checkbox, date range, cascader, person selector, `user-selector`, or other business components
- filter changes, clears, or component completion should auto apply by reloading/querying the table without requiring a page-level search button
- top search forms are reserved for cross-column keywords, global actions, very complex conditions, or filters not tied to a single column
- table parents must have stable height, such as `Page auto-content-height`, `flex h-full min-h-0`, and `<Grid class="h-full" />`
- `user-selector` for user selection flows
- keep feature API wrappers near the feature

Allowed table exceptions are small static nested tables in detail pages, temporary small data inside dialogs, or pure display matrices. Explain the exception in implementation notes or a code comment.

If multiple pages or columns need similar header filtering, first consider adding or reusing a zq-table companion filter configuration/component instead of repeating large page-level Popover implementations. One-off page-level header slots are acceptable only for special business filters.

## 7. Backend implementation rules

Use the repo's native backend shape:
- Django Ninja routes
- service layer for business logic
- model / schema / api separation when it matches the module
- keep validations close to the business logic
- add targeted tests for changed behavior

Comment requirements are mandatory:
- every new or modified function has a Chinese docstring or clear function comment
- every Django Ninja API has both a route `summary` and a function docstring
- complex branches, compatibility logic, permission checks, audit writes, status transitions, batch processing, async tasks, and paginated filters include inline comments
- comments should explain business intent, edge cases, or compatibility boundaries, not restate obvious code

## 8. Delivery support checks

For a new module, page, workflow, or permissioned action, decide whether it needs:
- frontend route and menu entry
- button permission and API permission code
- dictionary items
- initialization command or seed data
- migration or data backfill
- docs entry or module guide

These are not required for every task, but the implementation should make the decision deliberately instead of discovering the omission after handoff.

## 9. Verification rules

Minimum checks:
- `pnpm -C web lint` or the repo's targeted lint command
- `pnpm -C web typecheck` or the app-level typecheck command
- `python -m py_compile` for touched Python files
- targeted tests for changed behavior
- self-check that touched functions, backend APIs, and complex logic have required comments
- self-check that table-driven UI uses zq-table with explicit pagination, unless a documented exception applies
- self-check that column-bound filters are in header filter dropdowns rather than ordinary top search fields
- self-check that complex filters open from a Filter icon and auto apply after change, clear, or component completion
- self-check that repeated header filter behavior has been considered for a reusable zq-table companion configuration/component

For UI changes, add browser validation with Playwright.

## 10. When to reuse other skills

- `write-spec`: turning a rough request into a spec
- `roadmap-update`: reprioritizing work or tracking delivery order
- `synthesize-research`: summarizing feedback or notes before shaping the feature
- `frontend-design`: making the UI feel intentional instead of generic
- `webapp-testing`: checking the app in a browser

## 11. CRUD special case

If the task is a standard CRUD module, reuse the repo's CRUD convention rather than inventing a custom structure.

The skill should orchestrate the delivery process, not replace module conventions.
