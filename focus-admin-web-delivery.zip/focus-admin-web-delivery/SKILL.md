---
name: focus-admin-web-delivery
description: Use this skill for Focus Admin feature work that needs a structured path from spec to design, implementation, and verification across Django Ninja, Vue 3, Vben, zq-table, and MySQL 8. Trigger when the user asks for需求设计、文档落盘、设计稿、前后端联动开发、CRUD落地、测试验证, or any end-to-end web delivery in this repository.
---

# Focus Admin Web Delivery

## Overview

This skill turns a Focus Admin feature request into a concrete delivery flow: spec first, docs second, design direction third, implementation fourth, verification last.

Use it for work in this repo when the task spans product thinking, backend APIs, Vue 3 UI, Vben conventions, zq-table management screens, MySQL-backed data, and validation.

## Core Workflow

### 1. Start with the spec

Write a short feature spec before coding. Capture:
- problem and user need
- target users
- scope and non-scope
- API/page mapping
- acceptance criteria
- risks and open questions

If the request is vague, tighten it into a PRD-style note first. Use `write-spec` for this step.

### 2. Record the decision

Write the spec into the repo docs, not just chat.

Default locations:
- backend product / workflow specs: `backend-django/docs/`
- frontend or UI notes: `web/docs/` when the doc is frontend-facing
- project-specific deep dives: keep them near the owning backend module under `backend-django/docs/`

Prefer one page per feature. Keep it readable as a handoff artifact.

### 3. Lock the UI direction

For Focus Admin, design like an internal admin product:
- dense, scannable, task-focused layouts
- clear hierarchy over decorative polish
- reuse existing Vben patterns and components first
- avoid marketing-style composition and generic AI-looking visuals

If the task is UI-heavy, use `frontend-design` to push for a deliberate aesthetic direction, but keep it compatible with Vben and the current app shell.

### 4. Implement in the repo's shape

Use the repo's existing patterns before inventing new ones.

Backend expectations:
- Django Ninja endpoints
- service layer holds business logic
- model/schema/api split when the feature fits that pattern
- add tests when behavior changes
- every new or modified function has a Chinese docstring or clear function comment
- every Django Ninja API has a `summary` plus a function docstring
- complex branches, compatibility logic, permission/audit/status flows, batch work, async tasks, and paginated filters include inline comments explaining business intent or boundaries

Frontend expectations:
- `web/apps/web-ele/src/views/...`
- list pages usually have `index.vue` plus `data.ts`
- all management data lists, CRUD lists, dashboard detail lists, and paginated data tables must prefer `useZqTable` / `zq-table`
- zq-table pages explicitly configure pagination, usually `pagerConfig: { enabled: true, pageSize: 20 }`, with `pageSizes` added when useful
- `proxyConfig.ajax.query` maps `page.currentPage` to backend `page` and `page.pageSize` to backend `pageSize`
- column-bound filters must live in the matching table header cell as a header filter dropdown, not in the top search area by default
- simple enum filters should use Element Plus / zq-table column filter passthrough when it fits
- complex filters use a `header-*` slot or reusable zq-table header filter component with a column label, Filter icon, and dropdown panel
- header filter dropdowns may host inputs, radio, checkbox, date range, cascader, person selector, user-selector, or other business components
- filter changes, clears, or component completion should auto apply by reloading/querying the table without requiring a page-level search button
- top search forms are reserved for cross-column keywords, global actions, very complex conditions, or filters not tied to a single column
- table containers provide stable height, such as `Page auto-content-height`, `flex h-full min-h-0`, and `<Grid class="h-full" />`
- user picking should use `user-selector`
- keep API wrappers close to the feature

Allowed zq-table exceptions are limited to small static nested tables in detail pages, temporary small data inside dialogs, or pure display matrices. Explain the exception in implementation notes or a code comment.

If multiple pages or columns need similar header filtering, first consider adding or reusing a zq-table companion filter configuration/component instead of repeating large page-level Popover implementations. One-off page-level header slots are acceptable only for special business filters.

For standard CRUD modules, defer to the project's CRUD conventions and reuse them instead of inventing a new screen shape.

### 5. Check delivery support items

Before implementing a new module or entry point, decide whether it needs supporting configuration:
- frontend route and menu entry
- button permission and API permission code
- dictionary items
- initialization command or seed data
- migration or data backfill
- docs entry or module guide

These are not mandatory for every task, but the implementation should explicitly consider them when the feature adds a new module, page, workflow, or permissioned action.

### 6. Verify before handoff

Do not stop at code creation.

Minimum checks:
- frontend lint
- frontend typecheck
- backend Python compile
- targeted backend tests when logic changed
- comment coverage self-check for touched functions, APIs, and complex logic
- zq-table pagination self-check for table-driven UI
- header filter self-check for table-driven UI: column filters are in header dropdowns, complex filters open from a Filter icon, and changes auto apply
- reusable header filter self-check when multiple columns or pages repeat the same filter pattern

When the change affects UI behavior or layout, add browser verification with Playwright. Use `webapp-testing` for local app checks, screenshots, and interaction validation.

## Working Rules

- Prefer the smallest feature slice that solves the user problem.
- Keep docs, code, and tests aligned.
- Comments are a delivery requirement, not polish: explain business intent, edge cases, and non-obvious control flow without repeating obvious code.
- Table-driven admin pages default to zq-table with explicit pagination and header-cell filters; document any exception.
- Do not put ordinary column filters in the top search form by default; use header filter dropdowns and reserve top search for global or non-column conditions.
- Repeated header filter behavior should be generalized into zq-table companion configuration/components where practical.
- If the feature needs roadmap or research context, use `roadmap-update` or `synthesize-research` before implementation.
- If the feature is mainly a doc/spec task, keep the work in the spec and don't jump to code too early.
- If the task is about pure CRUD delivery, follow the repo CRUD convention first and keep the feature-specific skill as the orchestration layer.

## Output Standard

A good delivery should leave behind:
- a short spec in the docs tree
- a UI direction that matches Vben and admin workflows
- backend and frontend changes in the repo's native structure
- Chinese comments/docstrings on touched functions, backend APIs, and complex logic
- zq-table management lists with explicit pagination, unless a documented exception applies
- header-cell filter dropdowns for column-bound filters, including Filter-icon-triggered complex components with auto apply behavior
- passing verification commands or clearly noted gaps

## References

- See [project-delivery-guidelines.md](references/project-delivery-guidelines.md) for the repo-specific spec, doc, design, frontend, backend, and test rules.
